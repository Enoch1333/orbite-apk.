package com.bob.orbite;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
