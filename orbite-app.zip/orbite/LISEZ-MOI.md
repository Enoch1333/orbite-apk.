# Orbite — Projet d'application mobile (iOS + Android)

Ce dossier contient le jeu **Orbite** empaqueté avec [Capacitor](https://capacitorjs.com/) :
le même code web tourne comme vraie application native sur iPhone et Android.

- `www/` → le jeu (fichier `index.html`)
- `android/` → projet Android natif (à ouvrir dans Android Studio)
- `ios/` → projet iOS natif (à ouvrir dans Xcode, **Mac requis**)
- `capacitor.config.json` → configuration (nom, identifiant `com.bob.orbite`)

## Ce qu'il te faut

1. **Un ordinateur** avec Node.js 20+ installé (déjà utilisé pour créer ce projet).
2. **Pour Android** : Android Studio (Windows, Mac ou Linux).
3. **Pour iOS** : un Mac avec Xcode (Apple ne permet de compiler pour iPhone que sur Mac).
4. **Comptes développeur** (payants, à ton nom) :
   - Google Play : 25 $ US, paiement unique → https://play.google.com/console
   - Apple Developer Program : 99 $ US / an → https://developer.apple.com/programs/

## Compiler l'application

```bash
cd orbite
npm install          # réinstalle les dépendances (une seule fois)
npx cap sync         # recopie le jeu dans les projets natifs (à refaire si tu modifies www/)
```

- **Android** : ouvre le dossier `android/` dans Android Studio → Build → Generate Signed Bundle/APK → téléverse le fichier `.aab` sur la Play Console.
- **iOS** : ouvre le dossier `ios/App/App.xcworkspace` dans Xcode → choisis ton équipe de signature (ton compte Apple Developer) → Product → Archive → téléverse sur App Store Connect.

## Publier sur les stores

1. Crée la fiche de l'app (nom, description, captures d'écran, icône 102x1024 — voir `icon/`).
2. Remplis le questionnaire de contenu et la politique de confidentialité.
   (Le jeu ne collecte aucune donnée : tu peux l'indiquer tel quel.)
3. Envoie en révision. Compte quelques jours pour Apple, quelques heures/jours pour Google.

## Notes

- L'identifiant de l'app est `com.bob.orbite`. Si tu veux ton propre nom de domaine inversé
  (ex. `com.tonnom.orbite`), modifie-le dans `capacitor.config.json`, `android/app/build.gradle`
  (applicationId) et dans Xcode (Bundle Identifier), puis refais `npx cap sync`.
- Le mode « défi 10 $ » du jeu est un classement local entre amis : **aucun argent ne transite
  par l'application**. C'est toi qui remets le prix au gagnant.
- Pour mettre le jeu à jour plus tard : remplace `www/index.html`, relance `npx cap sync`,
  recompile et publie une nouvelle version sur chaque store.
